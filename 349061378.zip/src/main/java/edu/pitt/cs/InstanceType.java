package edu.pitt.cs;

public enum InstanceType {
	IMPL, BUGGY, SOLUTION, MOCK
}
